FirstName:YASMEEN
LastName:ALLAHALEH
Section: CSC_Fall23 : ProjectONE
ID: 2981504

README:  
